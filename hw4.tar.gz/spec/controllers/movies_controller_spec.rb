require 'spec_helper'

describe MoviesController do
  describe 'update movie' do
	it 'should add the director to the movie'
  end
end

